
# More GitHub Actions Examples


<img src="08-gha-other-examples_files/figure-html//1x0Cnk2Wcsg8HYkmXnXo_0PxmYCxAwzVrUQzb8DUDvTA_g290614d43ec_0_52.png" width="100%" style="display: block; margin: auto;" />
